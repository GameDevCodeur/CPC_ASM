# Tableau d'adressage mémoire écran de l'Amstrad CPC

| Ligne | Série 0 | Série 1 | Série 2 | Série 3 | Série 4 | Série 5 | Série 6 | Série 7 |
|-------|---------|---------|---------|---------|---------|---------|---------|---------|
| 0     | C000    | C050    | C0A0    | C0F0    | C140    | C190    | C1E0    | C230    |
| 1     | C800    | C850    | C8A0    | C8F0    | C940    | C990    | C9E0    | CA30    |
| 2     | D000    | D050    | D0A0    | D0F0    | D140    | D190    | D1E0    | D230    |
| 3     | D800    | D850    | D8A0    | D8F0    | D940    | D990    | D9E0    | DA30    |
| 4     | E000    | E050    | E0A0    | E0F0    | E140    | E190    | E1E0    | E230    |
| 5     | E800    | E850    | E8A0    | E8F0    | E940    | E990    | E9E0    | EA30    |
| 6     | F000    | F050    | F0A0    | F0F0    | F140    | F190    | F1E0    | F230    |
| 7     | F800    | F850    | F8A0    | F8F0    | F940    | F990    | F9E0    | FA30    |

| Ligne | Série 8 | Série 9 | Série 10 | Série 11 | Série 12 | Série 13 | Série 14 | Série 15 |
|-------|---------|---------|----------|----------|----------|----------|----------|----------|
| 0     | C280    | C2D0    | C320     | C370     | C3C0     | C410     | C460     | C4B0     |
| 1     | CA80    | CAD0    | CB20     | CB70     | CBC0     | CC10     | CC60     | CCB0     |
| 2     | D280    | D2D0    | D320     | D370     | D3C0     | D410     | D460     | D4B0     |
| 3     | DA80    | DAD0    | DB20     | DB70     | DBC0     | DC10     | DC60     | DCB0     |
| 4     | E280    | E2D0    | E320     | E370     | E3C0     | E410     | E460     | E4B0     |
| 5     | EA80    | EAD0    | EB20     | EB70     | EBC0     | EC10     | EC60     | ECB0     |
| 6     | F280    | F2D0    | F320     | F370     | F3C0     | F410     | F460     | F4B0     |
| 7     | FA80    | FAD0    | FB20     | FB70     | FBC0     | FC10     | FC60     | FCB0     |

| Ligne | Série 16 | Série 17 | Série 18 | Série 19 | Série 20 | Série 21 | Série 22 | Série 23 |
|-------|----------|----------|----------|----------|----------|----------|----------|----------|
| 0     | C500     | C550     | C5A0     | C5F0     | C640     | C690     | C6E0     | C730     |
| 1     | CD00     | CD50     | CDA0     | CDF0     | CE40     | CE90     | CEE0     | CF30     |
| 2     | D500     | D550     | D5A0     | D5F0     | D640     | D690     | D6E0     | D730     |
| 3     | DD00     | DD50     | DDA0     | DDF0     | DE40     | DE90     | DEE0     | DF30     |
| 4     | E500     | E550     | E5A0     | E5F0     | E640     | E690     | E6E0     | E730     |
| 5     | ED00     | ED50     | EDA0     | ED50     | EE40     | EE90     | EEE0     | EF30     |
| 6     | F500     | F550     | F5A0     | F550     | F640     | F690     | F6E0     | F730     |
| 7     | FD00     | FD50     | FDA0     | FD50     | FE40     | FE90     | FEE0     | FF30     |

| Ligne | Série 24 | spare start | spare end |
|-------|----------|-------------|-----------|
| 0     | C780     | C7D0        | C7FF      |
| 1     | CF80     | CFD0        | CFFF      |
| 2     | D780     | D7D0        | D7FF      |
| 3     | DF80     | DFD0        | DFFF      |
| 4     | E780     | E7D0        | E7FF      |
| 5     | EF80     | EFD0        | EFFF      |
| 6     | F780     | F7D0        | F7FF      |
| 7     | FF80     | FFD0        | FFFF      |
