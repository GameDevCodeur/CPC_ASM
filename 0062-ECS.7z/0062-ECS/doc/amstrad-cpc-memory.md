# Organisation de la Mémoire Graphique de l'Amstrad CPC

## Caractéristiques fondamentales
* **Taille totale**: 16 Ko
* **Largeur d'une ligne**: 80 caractères (octets) = &50 en hexadécimal
* **Adresse vidéo de base**: &C000

## Structure d'entrelacement
* Les lignes sont **entrelacées** et organisées en **séries de 8 lignes** consécutives
* Pour passer de la ligne 0 à la ligne 1: ajouter **&800** à l'adresse de base
* Pour passer de la ligne 0 à la ligne 8: ajouter **&50** (80 octets)
* Chaque nouvelle série commence avec un décalage de **&50**

## Calcul d'adresse d'une ligne

### Formule simple (première série)
```
[Adresse de base de la ligne] = &C000 + (&800 * n° de ligne)
```

### Formule complète (toutes séries)
1. **Déterminer la série**:
   ```
   Numéro de la série = (n° de ligne \ 8)
   ```

2. **Déterminer la position dans la série**:
   ```
   Numéro de la ligne dans la série = (n° de ligne MOD 8)
   ```

3. **Calculer l'adresse**:
   ```
   Adresse de base de la série = Adresse vidéo + (n° de la série * &50)
   Adresse de base de la ligne = Adresse de base de la série + (&800 * n° de la ligne dans la série)
   ```

### Exemple: Ligne 21
* Série: (21 \ 8) = 2
* Position: (21 MOD 8) = 5
* Adresse série: &C000 + (2 * &50) = &C0A0
* Adresse ligne: &C0A0 + (&800 * 5) = &E0A0

## Adressage d'un pixel
Pour trouver l'octet d'un pixel spécifique, ajouter:
```
Position X \ nombre de pixels par octet
```
