# LE XOR SUR Z80 : APPLICATIONS ET TECHNIQUES

## Introduction

Le XOR (eXclusive OR) est une opération logique fondamentale dans le jeu d'instructions du Z80. Ce microprocesseur 8-bits conçu par Zilog en 1976 a propulsé l'informatique personnelle avec des machines légendaires comme le ZX Spectrum, l'Amstrad CPC et le MSX. Le XOR, par sa simplicité et son élégance, a permis aux programmeurs de créer des solutions astucieuses à des problèmes d'optimisation dans un environnement aux ressources limitées.

## Bases mathématiques du XOR

L'opération XOR produit un résultat vrai (1) uniquement lorsque les opérandes diffèrent :

| A | B | A XOR B |
|---|---|---------|
| 0 | 0 |    0    |
| 0 | 1 |    1    |
| 1 | 0 |    1    |
| 1 | 1 |    0    |

Cette opération bit à bit possède plusieurs propriétés mathématiques remarquables :
- **Commutativité** : A ⊕ B = B ⊕ A
- **Associativité** : (A ⊕ B) ⊕ C = A ⊕ (B ⊕ C)
- **Auto-inverse** : A ⊕ A = 0
- **Neutralité du zéro** : A ⊕ 0 = A

## Implémentation dans le Z80

Le Z80 dispose d'instructions XOR optimisées qui affectent également les drapeaux du processeur :

```assembly
XOR A           ; 4 cycles, 1 octet - XOR accumulateur avec lui-même
XOR r           ; 4 cycles, 1 octet - XOR accumulateur avec registre
XOR n           ; 7 cycles, 2 octets - XOR accumulateur avec valeur immédiate
XOR (HL)        ; 7 cycles, 1 octet - XOR accumulateur avec contenu à l'adresse HL
XOR (IX+d)      ; 19 cycles, 3 octets - XOR avec contenu à IX+déplacement
XOR (IY+d)      ; 19 cycles, 3 octets - XOR avec contenu à IY+déplacement
```

## Applications techniques

### 1. Remise à zéro ultra-rapide

```assembly
XOR A           ; Efface A en 4 cycles vs LD A,0 qui prend 7 cycles
```

Cette technique est fréquemment utilisée dans les routines critiques où chaque cycle compte.

### 2. Test de parité

Le XOR est idéal pour calculer la parité d'un nombre :

```assembly
LD B,8          ; Compteur de bits
LD C,0          ; Initialise le résultat de parité
ParityLoop:
    SRL A       ; Décale A à droite, bit de poids faible dans Carry
    JR NC,NoXor ; Saute si bit = 0
    INC C       ; Incrémente le compteur de bits à 1
NoXor:
    DJNZ ParityLoop
    LD A,C
    AND 1       ; A contient maintenant la parité (0=pair, 1=impair)
```

### 3. Inversion des bits (NOT logique)

Contrairement à d'autres processeurs, le Z80 n'a pas d'instruction NOT dédiée :

```assembly
XOR 0xFF        ; Inverse tous les bits (NOT logique)
```

### 4. Échange de valeurs sans registre temporaire

```assembly
; Échange A et B sans registre auxiliaire
XOR B
LD B,A
XOR B
LD B,A
```

### 5. Techniques graphiques

#### Animation par XOR

Le XOR permet d'afficher et d'effacer des sprites sans altérer l'arrière-plan :

```assembly
DrawSprite:
    LD HL,SpriteData
    LD DE,ScreenAddress
    LD B,SpriteHeight
DrawLoop:
    LD A,(DE)       ; Charge pixel écran
    XOR (HL)        ; XOR avec sprite
    LD (DE),A       ; Écrit à l'écran
    INC HL          ; Sprite suivant
    INC DE          ; Écran suivant
    DJNZ DrawLoop
    RET
    
; Pour effacer, il suffit d'appeler à nouveau la même routine !
```

#### Masquage de bits dans les cartes de tiles

```assembly
LD A,(TileProperties)
XOR 00010000b   ; Bascule le bit 4 (exemple : traversable/non-traversable)
LD (TileProperties),A
```

### 6. Cryptographie simple

```assembly
; Chiffrement/déchiffrement XOR basique
LD HL,DataStart
LD BC,DataLength
LD D,KeyValue
EncryptLoop:
    LD A,(HL)
    XOR D          ; Chiffre/déchiffre avec la clé
    LD (HL),A
    INC HL
    DEC BC
    LD A,B
    OR C
    JR NZ,EncryptLoop
```

## Optimisations avancées

### Détection de bits communs

Cette technique permet de déterminer si deux valeurs ont des bits en commun :

```assembly
LD A,FirstValue
AND SecondValue   ; A contient les bits communs
XOR 0            ; Met Z=1 si aucun bit commun
JR Z,NoBitsInCommon
```

### Détection de changements

Le XOR peut identifier les bits qui diffèrent entre deux états :

```assembly
LD A,(OldState)
LD B,A
LD A,(NewState)
XOR B             ; A contient maintenant les bits qui ont changé
JP Z,NoChange     ; Si Z=1, aucun changement
```

## Conclusion

Le XOR est bien plus qu'une simple opération logique sur le Z80 - c'est un outil polyvalent qui a permis aux programmeurs de cette époque de créer des solutions élégantes avec des contraintes matérielles sévères. Sa capacité à simplifier l'échange de données, les opérations graphiques et les algorithmes de cryptographie en fait un pilier de la programmation en assembleur Z80, démontrant comment une instruction apparemment simple peut résoudre des problèmes complexes avec efficacité.
