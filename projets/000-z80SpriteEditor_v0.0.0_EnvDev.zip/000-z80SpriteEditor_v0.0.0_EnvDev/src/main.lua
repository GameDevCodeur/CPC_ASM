
-- Modules love2d
LG = love.graphics

-- Chargement des valeurs par defaut
function love.load()
--
--
end

-- Logique
function love.update(dt)
--
--
end

-- Affichage
function love.draw()
--
	LG.print("hello world !!", 10, 10)
--
end

-- Redimensionne la fenetre
function love.resize(w, h)	
--
--
end

-- Click souris
function love.mousepressed(x, y, button, istouch)
--
--
end

-- Pression touche du clavier
function love.keypressed(key)
--
--
end
