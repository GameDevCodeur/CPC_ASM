--
--
--

require "libs.GetStrChar"
require "libs.toEncode"
require "libs.CheckCollision"
require "libs.DrawBox"
