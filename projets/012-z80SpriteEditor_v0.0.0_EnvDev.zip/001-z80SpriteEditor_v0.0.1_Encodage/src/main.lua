
-- Modules love2d
LG = love.graphics

-- Modules Editeur
require "modules.EditeurModules"

-- Librairies Editeur
require "libs.EditeurLibs"

-- Modules CPC
M0 = CPC.M0

-- Chargement des valeurs par defaut
function love.load()
--
	p0="0011"
	p1="0011"
	pr = M0.toEncode(p0, p1)
--
end

-- Logique
function love.update(dt)
--
--
end

-- Affichage
function love.draw()
--
	LG.print(p0.." "..p1, 10, 10)
	LG.print(pr, 10, 30)
--
end

-- Redimensionne la fenetre
function love.resize(w, h)	
--
--
end

-- Click souris
function love.mousepressed(x, y, button, istouch)
--
--
end

-- Pression touche du clavier
function love.keypressed(key)
--
--
end
