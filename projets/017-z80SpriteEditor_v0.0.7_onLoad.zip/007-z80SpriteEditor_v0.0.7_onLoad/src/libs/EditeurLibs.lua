--
-- libs
--

require "libs.GetStrChar"
require "libs.toEncode"
require "libs.CheckCollision"
require "libs.DrawBox"
require "libs.onSave"
require "libs.onLoad"
