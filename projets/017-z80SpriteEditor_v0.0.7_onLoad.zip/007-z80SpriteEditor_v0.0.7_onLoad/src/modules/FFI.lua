--
--
--

local ffi = require "ffi"

ffi.cdef[[
	typedef struct {
	  char *fpos;
	  void *base;
	  unsigned short handle;
	  short flags;
	  short unget;
	  unsigned long alloc;
	  unsigned short buffincrement;
	} FILE;

	FILE *fopen(const char *filename, const char *mode);
	int fprintf(FILE *stream, const char *format, ...);
	int fclose(FILE *stream);
]]

local f = ffi.C.fopen("/tmp/test", "a+")
ffi.C.fprintf(f, "Hello World")
ffi.C.fclose(f)
