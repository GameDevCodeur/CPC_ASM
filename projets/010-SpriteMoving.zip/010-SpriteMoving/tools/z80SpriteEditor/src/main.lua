
LM = love.mouse
LG = love.graphics
LS = love.system
LF = love.filesystem
LW = love.window

require "lib.libs"
require "modules.CPC"
require "modules.palette"
require "modules.gridpixels"
require "modules.ButtonSave"
require "modules.ButtonLoad"
require "modules.Sprite"
							
local spriteGriHexColor = 
							{
								 {"$00","$00","$00","$00","$00","$00","$00","$00"},
								 {"$00","$00","$00","$00","$00","$00","$00","$00"},
								 {"$00","$00","$00","$00","$00","$00","$00","$00"},
								 {"$00","$00","$00","$00","$00","$00","$00","$00"},
								 {"$00","$00","$00","$00","$00","$00","$00","$00"},
								 {"$00","$00","$00","$00","$00","$00","$00","$00"},
								 {"$00","$00","$00","$00","$00","$00","$00","$00"},
								 {"$00","$00","$00","$00","$00","$00","$00","$00"},
								 {"$00","$00","$00","$00","$00","$00","$00","$00"},
								 {"$00","$00","$00","$00","$00","$00","$00","$00"},
								 {"$00","$00","$00","$00","$00","$00","$00","$00"},
								 {"$00","$00","$00","$00","$00","$00","$00","$00"},
								 {"$00","$00","$00","$00","$00","$00","$00","$00"},
								 {"$00","$00","$00","$00","$00","$00","$00","$00"},
								 {"$00","$00","$00","$00","$00","$00","$00","$00"},
								 {"$00","$00","$00","$00","$00","$00","$00","$00"},
							}

-- Charge les valeurs
function love.load()
--
	LF.setIdentity("z80SpriteEditor/")
	--
	z80SpriteEditor 				= {}
	z80SpriteEditor.Cursor 			= LM.getSystemCursor("hand")
	z80SpriteEditor.PalettePos 		= {x=32,	y=32*1}
	z80SpriteEditor.SpritePos 		= {x=32,	y=32*2}
	z80SpriteEditor.gridPixelsPos 	= {x=32,	y=32*2}
	z80SpriteEditor.btSavePos		= {x=32*18,	y=32*3}
	z80SpriteEditor.btLoadPos		= {x=32*18,	y=32*4}
--
end

-- Logique
function love.update(dt)
	LM.setCursor()
	palette.Update()
	btsave.Update()
	btload.Update()	
	gridPixels.Update()
end

-- Affichage
function love.draw()
--
	LG.setBackgroundColor(unpack(CPC.BLACK))
	--
	palette.Draw(z80SpriteEditor.PalettePos.x, z80SpriteEditor.PalettePos.y)
	--
	btsave.Draw(z80SpriteEditor.btSavePos.x, z80SpriteEditor.btSavePos.y, "Enregistrer ...")
	btload.Draw(z80SpriteEditor.btLoadPos.x, z80SpriteEditor.btLoadPos.y, "Charger ...")
	--
	sprite.Draw(z80SpriteEditor.SpritePos.x, z80SpriteEditor.SpritePos.y)
	gridPixels.DrawLine(z80SpriteEditor.gridPixelsPos.x, z80SpriteEditor.gridPixelsPos.y)
--	
end
--
function love.resize(w, h)	
	
end
--
function love.mousepressed(x, y, button, istouch)
--
	if button == 1 then
	--
		if (btsave.Pressed(x, y)==1) then sprite.save() end
		if (btload.Pressed(x, y)==1) then sprite.load() end
		palette.SetIndexColor(x, y)
		sprite.SetGridColor(x, y, palette.indexColor)
	--
	end
--
end
--
function love.keypressed(key)
--
    if key == "f1" then
	--
		encodeGridCM0()
		writeGridHexSpriteM0()
	--
    elseif key == "f2" then
	--
		--LF.remove("SpriteData.lua")
        --love.event.quit("restart")
	--
    end
--
end
--
function writeGridHexSpriteM0()
--	
	local DataSprite = "DATASPRITEM0: \n"
	--
	for j=1,16 do
	--
		local M0 = 2 -- M0 2 Lignes par pixels
		--
		while(M0>0) do
		--
			DataSprite = DataSprite.."\tDB "
			for i=1,8 do
			--
				DataSprite = DataSprite..spriteGriHexColor[j][i]..","
			--
			end	
		--
			DataSprite = DataSprite.."\n"
			M0 = M0 - 1
		--
		end
	--
	end		
	--success, message = LF.write("SpriteDataM0.asm", DataSprite, 16*16*4+27+16*3+26)
	LS.setClipboardText(DataSprite);
	--	
end
--
function encodeGridCM0()
--
	local c0
	local c1
	local xx
	local cM0
	--
	for y=1,16 do
	--
		xx = 1
	--
		for x=1,16,2 do
		--
			c0 = DectoBin(sprite.GridIndexColor[y][x]-1)
			c1 = DectoBin(sprite.GridIndexColor[y][x+1]-1)
		--			
			cM0 = CPC.MODE0.toEncodeBin(c0, c1)
			spriteGriHexColor[y][xx] = BintoHex(cM0)
			xx=xx+1
		--
		end
	--
	end	
	print(c0.." "..c1)
	print(cM0)
	print(BintoHex(cM0))
--
end



