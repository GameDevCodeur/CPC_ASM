
--
--
--

palette 				= {}
palette.ColorHeight 	= 32
palette.ColorWidth		= 32
palette.CountColors		= 16
palette.x				= 0
palette.y               = 0

palette.LineColor		= {}
palette.LineColor[1]	= {.8,.8,.3,1}
palette.LineColor[2]	= {.8,.8,.3,1}
palette.LineColor[3]	= {.8,.8,.3,1}
palette.LineColor[4]	= {.8,.8,.3,1}
palette.LineColor[5]	= {.8,.8,.3,1}
palette.LineColor[5]	= {.8,.8,.3,1}
palette.LineColor[6]	= {.8,.8,.3,1}
palette.LineColor[7]	= {.8,.8,.3,1}
palette.LineColor[8]	= {.8,.8,.3,1}
palette.LineColor[9]	= {.8,.8,.3,1}
palette.LineColor[10]	= {.8,.8,.3,1}
palette.LineColor[11]	= {.8,.8,.3,1}
palette.LineColor[12]	= {.8,.8,.3,1}
palette.LineColor[13]	= {.8,.8,.3,1}
palette.LineColor[14]	= {.8,.8,.3,1}
palette.LineColor[15]	= {.8,.8,.3,1}
palette.LineColor[16]	= {.8,.8,.3,1}

palette.color 	  = {}
palette.color[1]  = CPC.BLUE
palette.color[2]  = CPC.BRIGHTYELLO
palette.color[3]  = CPC.BRIGHTCYAN
palette.color[4]  = CPC.BRIGHTRED
palette.color[5]  = CPC.BRIGHTWHITE
palette.color[6]  = CPC.BLACK
palette.color[7]  = CPC.BRIGHTBLUE
palette.color[8]  = CPC.BRIGHTMARGENTA
palette.color[9]  = CPC.CYAN
palette.color[10] = CPC.YELLO
palette.color[11] = CPC.PASTELBLUE
palette.color[12] = CPC.PINK
palette.color[13] = CPC.BRIGHTGREEN
palette.color[14] = CPC.PASTELGREEN
palette.color[15] = CPC.BLUE
palette.color[16] = CPC.SKYBLUE

palette.indexColor = 1
--
palette.Update = function()
--
	for i=1, palette.CountColors do
	--
		if CheckCollision(LM.getX(), LM.getY(), 1, 1, 
					 	  i * palette.ColorWidth, palette.ColorHeight, 
						  palette.ColorWidth, palette.ColorHeight) then
		--
			LM.setCursor(z80SpriteEditor.Cursor)
			palette.LineColor[i] = {1,0.8,1,1}
			break
		--
		else
		--
			palette.LineColor[i] = {.8,.8,.3,1}
		--
		end
	--
	end
--
end
--
palette.SetIndexColor = function(mx, my)
--
	for i=1, palette.CountColors do
	--
		if CheckCollision(mx, my, 1, 1, 
					 	  i * palette.ColorWidth, palette.ColorHeight, 
						  palette.ColorWidth, palette.ColorHeight) then
		--
			palette.indexColor = i			
		--
		end
	--
	end
--
end
--
palette.DrawColorSelected = function()
--
	local posX = palette.x + ((palette.indexColor-1) * palette.ColorWidth)
	LG.setColor(.6 ,.4 ,.7 ,1)
	LG.rectangle("fill", posX+21, palette.y+1, 10, 10)
--
end
--
palette.Draw = function(x, y)
--
	palette.x = x
	palette.y = y
	--
	for i = 1, palette.CountColors do
	--
		local posX = x + ((i-1) * palette.ColorWidth)
		LG.setColor(unpack(palette.color[i]))
		LG.rectangle("fill", posX, y, palette.ColorWidth, palette.ColorHeight)
	--
		LG.setColor(unpack(palette.LineColor[i]))
		LG.rectangle("line", posX, y, palette.ColorWidth, palette.ColorHeight)
	--
	end
	--
	palette.DrawColorSelected()
--
end
--