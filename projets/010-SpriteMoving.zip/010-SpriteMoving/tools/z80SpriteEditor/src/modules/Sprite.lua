--
--
--

sprite  			= {}
--sprite.color	    = {}

sprite.x			= 0
sprite.y            = 0
sprite.NBLines 		= 16
sprite.NBColonnes 	= 16
sprite.ColorHeight 	= 32
sprite.ColorWidth 	= 32
sprite.FileName		= "SpriteData.lua"
sprite.Mode			= 0

-- sprite.ColorIndex 	= 1

sprite.GridIndexColor = 
						{
							{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
							{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
							{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
							{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
							{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
							{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
							{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
							{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
							{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
							{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
							{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
							{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
							{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
							{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
							{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
							{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
						}
--
sprite.save = function()
--
	-- 16 chiffres et 16 ',' par ligne
	local Size = (16 + 16) * sprite.NBLines
	local DataSprite = ""
	--
	for j = 1,16 do
	--
		for i = 1,16 do
		--
			DataSprite = DataSprite..sprite.GridIndexColor[j][i]..","
		--
		end
	--
	end	
	--
	success, message = LF.write(sprite.FileName, DataSprite, Size)
--	
end
--
sprite.load = function()
--
	local j = 1
	local i = 1
	--
	if LF.getInfo(sprite.FileName) then
	--
		file = LF.read(sprite.FileName)
		--
		for w in file:gmatch("(.-),") do
		--
			sprite.GridIndexColor[j][i] = tonumber(w)
			--
			if i == sprite.NBLines then
			--
				j = j + 1
				i = 1
			--
			else
			--
				i = i + 1
			--
			end
		--
		end
	--
    end
--
end
--					
sprite.Draw = function(x, y)
--
	sprite.x = x
	sprite.y = y
	--
	for j = 1, sprite.NBColonnes do
	--
		local posY = j * sprite.ColorHeight + y
		--
		for i = 1, sprite.NBLines do
		--
			local posX = ((i-1) * sprite.ColorWidth) + x
		--
			LG.setColor(unpack(palette.color[sprite.GridIndexColor[j][i]]))					
			LG.rectangle("fill", posX, posY, sprite.ColorWidth, sprite.ColorHeight)
		--
		end
	--
	end
--
end
--
sprite.SetGridColor = function(mx, my, indexColor)
--
	for j = 1, sprite.NBColonnes do
	--
		local posY = j * sprite.ColorHeight + sprite.y
		--
		for i = 1, sprite.NBLines do
		--
			local posX = i * sprite.ColorWidth
			--
			if CheckCollision(mx, my, 1, 1, 
							  posX, posY, sprite.ColorHeight, sprite.ColorWidth) then
			--	
				if sprite.Mode==0 then
				--
					sprite.GridIndexColor[j][i]= indexColor
					sprite.GridIndexColor[j][i+1]= indexColor
				--
				end
				
				break
			--
			end
		--
		end
	--
	end
--
end
--