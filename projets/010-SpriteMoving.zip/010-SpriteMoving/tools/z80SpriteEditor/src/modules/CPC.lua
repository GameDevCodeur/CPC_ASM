--
--
--

CPC 				= {}
CPC.BLACK 			= { 0 , 0 , 0 ,1} --  0
CPC.BLUE			= { 0 , 0 , 1 ,1} --  1
CPC.BRIGHTBLUE 		= { 0 , 0 , 1 ,1} --  2 
CPC.RED				= {.5 , 0 , 0 ,1} --  3
CPC.MAGENTA 		= {.5 , 0 ,.5 ,1} --  4
CPC.MAUVE			= {.5 , 0 , 1 ,1} --  5
CPC.BRIGHTRED 		= { 1 , 0 , 0 ,1} --  6
CPC.PURPLE 			= { 1 , 0 ,.5 ,1} --  7
CPC.BRIGHTMARGENTA  = { 1 , 0 , 1 ,1} --  8
CPC.GREEN 			= { 0 ,.5 , 0 ,1} --  9 
CPC.CYAN 			= { 0 ,.5 ,.5 ,1} -- 10
CPC.SKYBLUE	 		= { 0 ,.5 , 1 ,1} -- 11
CPC.YELLO 			= {.5 ,.5 , 0 ,1} -- 12
CPC.WHITE 			= {.5 ,.5 ,.5 ,1} -- 13
CPC.PASTELBLUE	 	= {.5 ,.5 , 1 ,1} -- 14
CPC.ORANGE	 		= { 1 ,.5 , 0 ,1} -- 15
CPC.PINK 			= { 1 ,.5 ,.5 ,1} -- 16
CPC.PASTELMAGENTA	= { 1 ,.5 , 1 ,1} -- 17 
CPC.BRIGHTGREEN 	= { 0 , 1 , 0 ,1} -- 18
CPC.SEAGREEN  		= { 0 , 1 ,.5 ,1} -- 19 
CPC.BRIGHTCYAN	 	= { 0 , 1 , 1 ,1} -- 20
CPC.LIMEGREEN 		= {.5 , 1 , 0 ,1} -- 21
CPC.PASTELGREEN		= {.5 , 1 ,.5 ,1} -- 22
CPC.PASTELCYAN 		= {.5 , 1 , 1 ,1} -- 23
CPC.BRIGHTYELLO 	= { 1 , 1 , 0 ,1} -- 24
CPC.PASTELYELLO  	= { 1 , 1 ,.5 ,1} -- 25
CPC.BRIGHTWHITE 	= { 1 , 1 , 1 ,1} -- 26

CPC.MODE0			= {}
CPC.MODE0.Pixel		= {P0=0, P1=0}

CPC.MODE0.toEncodeBin = function(p0, p1)
--
	CPC.MODE0.Pixel.P0 = po
	CPC.MODE0.Pixel.P1 = p1
	--
	local cB7 = GetStrChar(p0,4) -- C0B0 -- bit 7
	local cB6 = GetStrChar(p1,4) -- C1B0 -- bit 6	
	local cB5 = GetStrChar(p0,2) -- C0B2 -- bit 5
	local cB4 = GetStrChar(p1,2) -- C1B2 -- bit 4	
	local cB3 = GetStrChar(p0,3) -- C0B1 -- bit 3
	local cB2 = GetStrChar(p1,3) -- C1B1 -- bit 2
	local cB1 = GetStrChar(p0,1) -- C0B3 -- bit 1
	local cB0 = GetStrChar(p1,1) -- C1B3 -- bit 0
	--	
	return cB7..cB6..cB5..cB4..cB3..cB2..cB1..cB0
--
end
