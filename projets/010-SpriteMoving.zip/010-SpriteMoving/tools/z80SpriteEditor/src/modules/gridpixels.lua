--
--
--

gridPixels 				= {}
gridPixels.x			= 0
gridPixels.y            = 0
gridPixels.NBLines 		= 16
gridPixels.NBColonnes 	= 16
gridPixels.ColorHeight 	= 32
gridPixels.ColorWidth 	= 32
gridPixels.ColorLine	= {.8,.8,.3,1}

--
gridPixels.Update = function()
--
	local posX = gridPixels.x
	local posY = gridPixels.y + gridPixels.ColorHeight
	--
	if CheckCollision(LM.getX(), LM.getY(), 4, 4, 
				 	  posX, posY, 
					  gridPixels.NBLines * gridPixels.ColorWidth, 
					  gridPixels.NBColonnes * gridPixels.ColorHeight) then
	--
		LM.setCursor(z80SpriteEditor.Cursor)
	--
	end
--
end
--
gridPixels.DrawLine = function(x, y)
--
	gridPixels.x = x
	gridPixels.y = y
	--
	for j = 1, gridPixels.NBColonnes do
	--
		local posY = j * gridPixels.ColorHeight + y
		--
		for i = 1, gridPixels.NBLines do
		--
			local posX = ( (i-1) * gridPixels.ColorWidth ) + x		
		--
			LG.setColor(unpack(gridPixels.ColorLine))	
			LG.rectangle("line", posX, posY, gridPixels.ColorWidth, gridPixels.ColorHeight)
		--
		end
	--
	end
--
end
--
