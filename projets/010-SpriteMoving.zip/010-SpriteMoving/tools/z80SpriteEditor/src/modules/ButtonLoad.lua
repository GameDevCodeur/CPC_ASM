--
----
--
btload 				= {}
btload.height 		= 32 
btload.width 		= 32 * 6
btload.x			= 0
btload.y			= 0
btload.color		= CPC.SKYBLUE
btload.lineColor	= {.8,.8,.3,1}
btload.text			= ""
btload.textColor	= CPC.BRIGHTWHITE
btload.font			= LG.newFont("font/ASMAN.ttf", 25)
btload.textOffsetX	= 25
btload.textOffsetY	= 5

btload.Draw = function (x, y, text)
--
	btload.text = text
	btload.x = x
	btload.y = y
	--
	LG.setColor(unpack(btload.color))
	LG.rectangle("fill", btload.x, btload.y, btload.width, btload.height)
	--
	LG.setColor(unpack(btload.lineColor))
	LG.rectangle("line", btload.x, btload.y, btload.width, btload.height)
	--
	LG.setFont(btload.font)
	LG.setColor(unpack(btload.textColor))
	LG.print(text, x+btload.textOffsetX, y+btload.textOffsetY)
--
end
--
btload.Update = function ()
--
	btload.textColor = CPC.BRIGHTWHITE
	if CheckCollision(LM.getX(), LM.getY(), 1, 1, 
					  btload.x, btload.y, 
					  btload.width, btload.height) then
	--
		LM.setCursor(z80SpriteEditor.Cursor)		
		btload.textColor = CPC.BRIGHTMARGENTA
	--
	end
--
end
--
btload.Pressed = function (mx, my)
--
	if CheckCollision(mx, my, 1, 1, 
					  btload.x, btload.y, 
					  btload.width, btload.height) then
	--
		local title = "Charger ... "
		local message = "Etes-vous sur ?"
		local buttons = {"OK", "No!", escapebutton = 2}
		local pressedbutton = LW.showMessageBox(title, message, buttons, "info", true)
		return pressedbutton
	--
	end
--
end
--