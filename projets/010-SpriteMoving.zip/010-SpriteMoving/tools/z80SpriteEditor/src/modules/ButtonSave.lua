--
--
--
btsave 				= {}
btsave.height 		= 32 
btsave.width 		= 32 * 6
btsave.x			= 0
btsave.y			= 0
btsave.color		= CPC.SKYBLUE
btsave.lineColor	= {.8,.8,.3,1}
btsave.text			= ""
btsave.textColor	= CPC.BRIGHTWHITE
btsave.font			= LG.newFont("font/ASMAN.ttf", 25)
btsave.textOffsetX	= 25
btsave.textOffsetY	= 5
--
btsave.Draw = function (x, y, text)
--
	btsave.text = text
	btsave.x = x
	btsave.y = y
	--
	LG.setColor(unpack(btsave.color))
	LG.rectangle("fill", btsave.x, btsave.y, btsave.width, btsave.height)
	--
	LG.setColor(unpack(btsave.lineColor))
	LG.rectangle("line", btsave.x, btsave.y, btsave.width, btsave.height)
	--
	LG.setFont(btsave.font)
	LG.setColor(unpack(btsave.textColor))
	LG.print(text, x+btsave.textOffsetX, y+btsave.textOffsetY)
--
end
--
btsave.Update = function ()
--
	btsave.textColor = CPC.BRIGHTWHITE
	--
	if CheckCollision(LM.getX(), LM.getY(), 4, 4, 
					  btsave.x, btsave.y, 
					  btsave.width, btsave.height) then
	--
		LM.setCursor(z80SpriteEditor.Cursor)		
		btsave.textColor = CPC.BRIGHTMARGENTA
	--
	end
--
end
--
btsave.Pressed = function (mx, my)
--
	if CheckCollision(mx, my, 4, 4, 
					  btsave.x, btsave.y, 
					  btsave.width, btsave.height) then
	--
		local title = "Enregistrer... "
		local message = "Etes-vous sur ?"
		local buttons = {"OK", "No!", escapebutton = 2}
		local pressedbutton = LW.showMessageBox(title, message, buttons, "info", true)
		return pressedbutton
	--
	end
--
end
--