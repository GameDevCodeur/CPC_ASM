--
--
--

function GetStrChar(str, pos)
--
    return string.sub(str, pos, pos)
--
end
--