--
--
--

GetStrChar = function (str, pos)
--
    return string.sub(str, pos, pos)
--
end
--