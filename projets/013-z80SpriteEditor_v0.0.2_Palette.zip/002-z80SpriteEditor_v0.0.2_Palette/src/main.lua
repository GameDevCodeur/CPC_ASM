
-- Modules love2d
LG = love.graphics
LM = love.mouse

-- Modules Editeur
require "modules.EditeurModules"

-- Librairies Editeur
require "libs.EditeurLibs"

-- Modules CPC
M0 = CPC.M0
PL = PALETTE

--
-- Chargement des valeurs par defaut
--
function love.load()
--
	PL.Load({x = 32 * 1, y = 32 * 1}) -- X:800=32*25, Y:640=32*20
--
end

--
-- Logique
--
function love.update(dt)
--
	LM.setCursor()
	--
	PL.Update()
--
end

--
-- Affichage
--
function love.draw()
--
	--
	LG.setBackgroundColor(unpack(CPC.BLACK))
	--
	PL.Draw()
	--
	LG.setColor(unpack(CPC.BRIGHTWHITE))
	--
	LG.print(PL.ColorIndex)
--
end

--
-- Redimensionne la fenetre
--
function love.resize(w, h)	
--
--
end

--
-- Clique sur la souris
--
function love.mousepressed(mx, my, button, istouch)
--	
	PL.MousePressed(mx, my, button, istouch)
--
end

--
-- Pression touche du clavier
--
function love.keypressed(key)
--
--
end
