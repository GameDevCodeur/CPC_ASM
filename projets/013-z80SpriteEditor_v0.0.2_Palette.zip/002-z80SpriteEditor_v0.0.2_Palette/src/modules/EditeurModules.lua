
--
-- Charge les modules
--

require "modules.CPC"
require "modules.PALETTE"
