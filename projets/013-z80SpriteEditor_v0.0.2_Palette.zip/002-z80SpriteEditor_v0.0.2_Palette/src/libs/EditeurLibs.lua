
--
-- Charge les fonctions de la librairie
--

require "libs.GetStrChar"
require "libs.toEncode"
require "libs.CheckCollision"
require "libs.DrawBox"
