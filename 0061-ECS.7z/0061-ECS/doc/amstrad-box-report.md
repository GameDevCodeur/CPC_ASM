# Rapport Technique : Programmation d'une Boîte Graphique sur Amstrad CPC 464

## Résumé exécutif

Ce rapport présente les résultats d'une étude technique sur la programmation d'une boîte graphique pleine sur ordinateur Amstrad CPC 464. L'objectif était de développer un programme en assembleur Z80 permettant de créer efficacement des rectangles pleins dans différents modes graphiques. Après diverses tentatives, nous avons atteint une solution optimale utilisant les routines firmware natives de la machine, offrant un équilibre entre performance et facilité d'implémentation.

## Contexte technique

L'Amstrad CPC 464 est un micro-ordinateur 8 bits lancé en 1984, équipé d'un processeur Zilog Z80A cadencé à 4 MHz. Il dispose de trois modes graphiques distincts :

- **Mode 0** : 160×200 pixels, 16 couleurs
- **Mode 1** : 320×200 pixels, 4 couleurs
- **Mode 2** : 640×200 pixels, 2 couleurs

La programmation graphique sur cette machine peut être réalisée soit par l'accès direct à la mémoire vidéo, soit par l'utilisation des routines firmware intégrées dans la ROM. Ces routines constituent une interface standardisée pour les opérations graphiques, facilitant le développement tout en maintenant une compatibilité maximale.

## Méthodologie

Notre approche s'est déroulée en trois phases principales :

1. **Analyse préliminaire des méthodes disponibles**
   - Étude des techniques d'accès direct à la mémoire vidéo
   - Évaluation des routines firmware disponibles
   - Identification des compromis performance/simplicité

2. **Développement et test de plusieurs implémentations**
   - Méthode pixel par pixel (approche iterative)
   - Utilisation de la routine GRA_BOX du firmware
   - Adaptation aux différents modes graphiques

3. **Optimisation et documentation**
   - Sélection de l'approche la plus efficace
   - Documentation détaillée du code et des routines utilisées
   - Création de versions spécifiques pour chaque mode graphique

## Résultats techniques

### Solution retenue pour le Mode 1

Le programme assembleur suivant permet de dessiner une boîte pleine en Mode 1 :

```assembly
org &8000

start:
    LD A,1           ; Mode 1
    CALL &BC0E       ; SCR_SET_MODE
    
    ; Coordonnées du premier coin
    LD DE,50         ; X1
    LD HL,50         ; Y1
    CALL &BB6C       ; GRA_SET_PEN
    
    ; Définir le coin opposé
    LD BC,150        ; X2 (50+100)
    LD DE,130        ; Y2 (50+80)
    
    ; Dessiner la boîte pleine
    CALL &BB8A       ; GRA_BOX (dessiner une boîte)
    
    RET
```

Cette solution utilise la routine firmware `GRA_BOX` (adresse &BB8A) qui dessine automatiquement un rectangle plein entre deux points. Cette approche est significativement plus performante qu'une implémentation manuelle qui placerait des pixels individuellement.

### Adaptation pour le Mode 0

Pour le Mode 0, qui offre une palette de 16 couleurs mais une résolution horizontale réduite, le programme a été adapté comme suit :

```assembly
org &8000

start:
    LD A,0           ; Mode 0 (160x200, 16 couleurs)
    CALL &BC0E       ; SCR_SET_MODE
    
    ; Définir la couleur de dessin
    LD A,9           ; Couleur 9
    CALL &BB90       ; GRA_SET_PEN 
    
    ; Coordonnées du premier coin
    LD DE,40         ; X1
    LD HL,50         ; Y1
    CALL &BB6C       ; GRA_SET_PEN (positionner le curseur)
    
    ; Définir le coin opposé
    LD BC,120        ; X2 (40+80)
    LD DE,130        ; Y2 (50+80)
    
    ; Dessiner la boîte pleine
    CALL &BB8A       ; GRA_BOX (dessiner une boîte)
    
    RET
```

## Analyse des routines firmware utilisées

### SCR_SET_MODE (&BC0E)
Cette routine configure le mode d'affichage. Elle attend dans le registre A le numéro du mode (0, 1 ou 2) et modifie en conséquence la résolution et le nombre de couleurs disponibles.

### GRA_SET_PEN (&BB90)
Cette routine définit la couleur de dessin active. Elle utilise la valeur dans le registre A comme index dans la palette de couleurs. Le nombre de couleurs disponibles dépend du mode graphique sélectionné.

### GRA_SET_PEN (&BB6C)
Malgré son nom similaire à la routine précédente, cette fonction positionne le curseur graphique aux coordonnées absolues spécifiées par les registres DE (coordonnée X) et HL (coordonnée Y).

### GRA_BOX (&BB8A)
Cette routine dessine un rectangle plein entre la position actuelle du curseur graphique et les coordonnées spécifiées dans les registres BC (coordonnée X) et DE (coordonnée Y).

## Conclusions et recommandations

1. **Efficacité des routines firmware**
   L'utilisation des routines firmware constitue la méthode la plus efficace pour dessiner des formes géométriques sur l'Amstrad CPC 464, offrant un bon équilibre entre performance et simplicité du code.

2. **Choix du mode graphique**
   Le choix entre Mode 0 et Mode 1 dépend des besoins spécifiques de l'application :
   - Le Mode 0 est préférable lorsqu'une palette de couleurs étendue est nécessaire.
   - Le Mode 1 offre une meilleure résolution horizontale mais limite les couleurs à 4.

3. **Extensibilité**
   Ce programme peut facilement être étendu pour créer diverses formes graphiques ou être intégré dans des applications plus complexes, comme des jeux ou des interfaces utilisateur.

4. **Optimisations potentielles**
   Pour des applications nécessitant une performance maximale, l'accès direct à la mémoire vidéo pourrait être envisagé, bien que cela complexifie considérablement le code et réduise sa portabilité.

## Perspectives

Ce travail constitue une base solide pour le développement d'applications graphiques sur Amstrad CPC 464. Les techniques présentées peuvent être étendues pour créer des interfaces utilisateur complètes, des animations, ou des jeux. Des recherches futures pourraient explorer l'optimisation de ces routines pour des scénarios spécifiques ou le développement de bibliothèques graphiques plus élaborées.

---

*Rapport préparé le 3 mars 2025*
